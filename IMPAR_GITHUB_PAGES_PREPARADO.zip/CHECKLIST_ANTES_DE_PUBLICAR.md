# ÍMPAR TECHNOLOGY — checklist para publicação segura

## Preparação
- [x] Site copiado para pasta isolada, sem código de outros projetos.
- [x] Caminhos HTML/CSS/JS e imagens locais verificados estaticamente.
- [x] WhatsApp e endereço informados no site.
- [x] Fotos identificadas como ilustrativas, sem alegar que sejam registros reais.
- [x] Nenhum link para APK ou arquivos de aplicativos incluído.
- [ ] Confirmar autorização para publicação das cinco imagens, inclusive direitos de imagem das pessoas nelas retratadas.
- [ ] Confirmar que o endereço nº 27 pode ser divulgado publicamente e se há atendimento presencial.

## Conferência no celular, tablet e desktop (PENDENTE)
- [ ] Abrir página em 360px e 390px: sem conteúdo cortado ou rolagem horizontal.
- [ ] Abrir e fechar menu; teclado Escape deve fechar.
- [ ] Abrir todas as seções pelo menu.
- [ ] Conferir 4 imagens da galeria e logotipo.
- [ ] Testar WhatsApp e link do mapa no aparelho.
- [ ] Abrir em 768px e 1440px: textos, cartões e rodapé sem cortes.
- [ ] Verificar contraste/teclado/leitor de tela manualmente.
- [ ] Confirmar que a apresentação de cada projeto respeita o estado real de desenvolvimento.

## GitHub / segurança
- [ ] Criar repositório **público** `giovani-PLAY/impar-technology-site`, separado dos privados.
- [ ] Enviar apenas o conteúdo da pasta `site_para_repositorio`, sem a pasta-mãe e sem arquivos pessoais.
- [ ] Conferir no repositório que não há `*.apk`, `.env`, credenciais, banco de dados ou repositórios internos.
- [ ] Só depois de aprovar a prévia e direitos de imagens, habilitar Settings → Pages → Deploy from a branch → main → /(root).
- [ ] Abrir o endereço publicado em modo anônimo e testar navegação e contato.
- [ ] Verificar o histórico da publicação no GitHub Actions.

**Não publicar antes de fechar as pendências.**
