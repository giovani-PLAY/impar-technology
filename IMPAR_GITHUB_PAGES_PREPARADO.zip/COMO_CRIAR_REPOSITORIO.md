# Criar o repositório separado — GitHub

1. Acesse https://github.com/new estando logado como `giovani-PLAY`.
2. Nome: `impar-technology-site`. Escolha **Public** para GitHub Pages no GitHub Free.
3. Crie o repositório sem adicionar `.gitignore`, licença ou README automaticamente.
4. Abra o repositório → **Add file** → **Upload files** e envie **o conteúdo** de `site_para_repositorio/` (arquivos `index.html`, `styles.css`, `script.js`, `README.md`, `.nojekyll` e diretório `assets/`). Confira a árvore antes de confirmar o commit.
5. **Pare aqui** para a revisão: não habilite Pages antes da aprovação do teste mobile e das autorizações de imagem.
6. Depois dos testes, em **Settings → Pages → Build and deployment**, selecione **Deploy from a branch**, **main**, **/(root)** e **Save**.
7. A URL esperada é `https://giovani-play.github.io/impar-technology-site/`. Este endereço é **previsto, não validado como publicado**.

**Importante:** se a interface Upload files não preservar as subpastas, utilize o GitHub Desktop ou o comando `git`, em vez de achatar `assets/`.
